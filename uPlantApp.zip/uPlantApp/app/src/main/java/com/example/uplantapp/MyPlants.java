package com.example.uplantapp;

import java.io.Serializable;
import java.util.ArrayList;

public class MyPlants implements Serializable {
    private ArrayList<Plant> plants;

    public MyPlants(){
        plants = new ArrayList<>();
    }

    public void addPlant(Plant p){
        plants.add(p);
    }

    public ArrayList<Plant> getPlants(){
        return plants;
    }
}
