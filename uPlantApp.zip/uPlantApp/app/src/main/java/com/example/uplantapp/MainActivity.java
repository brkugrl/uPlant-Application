package com.example.uplantapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MainActivity extends AppCompatActivity {

    private Button mPlantButton;
    private Button mDocumentationButton;
    private Button mAddPlantButton;
    private ImageView mImg;
    Bitmap image=null;
    URL url=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPlantButton = (Button) findViewById(R.id.main_activity_plants_btn);
        mPlantButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent plantsActivity = new Intent(MainActivity.this, PlantsListing.class);
                startActivity(plantsActivity);
            }
        });


        mAddPlantButton = (Button) findViewById(R.id.main_activity_add_btn);
        mAddPlantButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myPlantsAddActivity = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(myPlantsAddActivity);
            }
        });

    }
    public void openActivity(){
        Intent intent = new Intent(this,Main2Activity.class);
        startActivity(intent);
    }
}
