package com.example.uplantapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
    private RecyclerView recycler_view;
    private List<Plant> plant_list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        recycler_view = (RecyclerView)findViewById(R.id.recycler_view);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        layoutManager.scrollToPosition(0);

        recycler_view.setLayoutManager(layoutManager);

        plant_list = new ArrayList<Plant>();

        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(getAssets().open("plant_data.csv"), "UTF-8"));
            String mLine;
            reader.readLine();

            int waterLevel = -1;
            int lightLevel = -1;
            while ((mLine = reader.readLine()) != null) {
                List<String> lineList = Arrays.asList(mLine.split(","));
                //Plant curr = new Plant(lineList.get(0), Integer.valueOf(lineList.get(1)), Integer.valueOf(lineList.get(2)));
                Plant curr = new Plant(lineList.get(0), Integer.valueOf(lineList.get(1)), Integer.valueOf(lineList.get(2)), R.drawable.plant_image);
                plant_list.add(curr);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        SimpleRecyclerAdapter adapter_items = new SimpleRecyclerAdapter(plant_list, new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {
                Log.d("Plant", "name:" + plant_list.get(position).getName());
                Log.d("Plant", "water:" + plant_list.get(position).getWaterLevel());
                Log.d("Plant", "light:" + plant_list.get(position).getLightLevel());
                Plant plant = plant_list.get(position);
                Toast.makeText(getApplicationContext(),"pozisyon:"+" "+position+" "+"Ad:"+plant.getName(),Toast.LENGTH_SHORT).show();
                openActivity(plant_list.get(position).getName(), plant_list.get(position).getWaterLevel(), plant_list.get(position).getLightLevel());
            }
        });
        recycler_view.setHasFixedSize(true);

        recycler_view.setAdapter(adapter_items);

        recycler_view.setItemAnimator(new DefaultItemAnimator());


    }

    public void openActivity(String plant_name, int water_level, int light_level){
        Intent intent = new Intent(this,Main3Activity.class);
        intent.putExtra("name", plant_name);
        intent.putExtra("water", "" + water_level);
        intent.putExtra("light", "" + light_level);
        startActivity(intent);
    }

}
