package com.example.uplantapp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;

import org.json.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;


public class PlantsListing extends AppCompatActivity {
    /*ListView mListView;
    View view;
    private EditText outputText;*/
    private TextView mTextViewResult;
    ListView mListView;
    /*public String[] prenoms = new String[]{
            "Plant1", "Plant2", "Plant3", "Plant4", "Plant5"};*/
    public static ArrayList<String> prenoms = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plants_listing);

        mTextViewResult=findViewById(R.id.text_view_result);
        //Button WaterButton= findViewById(R.id.button);

        mListView = (ListView) findViewById(R.id.listView);

        /*
        // Deserialization
        try
        {
            // Reading the object from a file
            FileInputStream file = openFileInput("plants.ser");
            ObjectInputStream in = new ObjectInputStream(file);

            // Method for deserialization of object
            MyPlants plants = (MyPlants)in.readObject();

            in.close();
            file.close();

            System.out.println("Object has been deserialized ");
            System.out.println(plants.getPlants().toString());
        }

        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }

        catch(ClassNotFoundException ex)
        {
            System.out.println("ClassNotFoundException is caught");
        }
        */

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(PlantsListing.this,
                android.R.layout.simple_list_item_1, prenoms);
        mListView.setAdapter(adapter);



      /* WaterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Send a message
            }
        });*/

    }

/*private void jsonParse(){
        String url="https://api.myjson.com/bins/tkhrf";
        JsonObjectRequest request= new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("Plants"); //surround with try/catch

                    for(int i=0; i<jsonArray.length(); i++){
                        JSONObject plant=jsonArray.getJSONObject(i);

                        int id=plant.getInt("id");
                        String name=plant.getString("name");
                        String waterlevel=plant.getString("waterlevel");
                        String brightness=plant.getString("brightness");

                        mTextViewResult.append(name+","+waterlevel+"\n\n");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }); //methodes a 5 arguments

    mQueue.add(request);
}*/

}
