package com.example.uplantapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telecom.Call;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;



public class PlantInformationActivity extends AppCompatActivity {

    private Button JSONGetButton;
    private Button JSONPostButton;
    private TextView mytextViewResult1;
    private TextView mytextViewResult2;
    ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_information);
       /* mListView = (ListView) findViewById(R.id.listView);

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(PlantInformationActivity.this,
                android.R.layout.simple_list_item_1, prenoms);
        mListView.setAdapter(adapter);*/
        JSONGetButton = (Button)findViewById(R.id.JSONGetbutton);
        mytextViewResult1 = findViewById(R.id.text_view_result);

        JSONPostButton = (Button)findViewById(R.id.JSONPostbutton);

        /****************************************************************************************************/
        /****************************************************************************************************/
        JSONGetButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                OkHttpClient client = new OkHttpClient();
                String url = "https://reqres.in/api/users?page=2";
                //String url = "http://time.jsontest.com/";
                //String url = "https://www.google.com";

                Request request = new Request.Builder()
                        .url(url)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(okhttp3.Call call, Response response) throws IOException {
                        if (response.isSuccessful()) {
                            final String myResponse = response.body().string();

                            PlantInformationActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {


                                    try {
                                        System.out.println(myResponse);
                                        JSONObject json_response = new JSONObject(myResponse);
                                        System.out.println(json_response);
                                        //System.out.println(json_response.getString("data").getClass().getName());/*
                                        //JSONObject json_data = new JSONObject();

                                        System.out.println(json_response.getJSONArray("data"));
                                        System.out.println(json_response.getJSONArray("data").getJSONObject(0).getString("id"));
                                        //mtextViewResult.setText(json_response.getJSONObject("data").getString("id"));
                                        mytextViewResult1.setText(json_response.getJSONArray("data").getJSONObject(0).getString("id"));

                                    } catch (JSONException e) {
                                        Log.e("MYAPP", "unexpected JSON exception", e);
                                    }
                                }
                            });
                        }
                    }
                });


                openActivity();
            }
        });
        /****************************************************************************************************/
        /****************************************************************************************************/


        /****************************************************************************************************/
        /****************************************************************************************************/


        /****************************************************************************************************/
        /****************************************************************************************************/
    }

    public void openActivity(){
        Intent intent = new Intent(this,Main2Activity.class);
        startActivity(intent);
    }
}

