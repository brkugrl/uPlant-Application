package com.example.uplantapp;


import java.io.Serializable;

public class Plant implements Serializable {
    private String name;
    private int lightLevel;
    private int waterLevel;
    private int photo_id;


    public String getName()
    {
        return this.name;
    }
    public int getWaterLevel()
    {
        return this.waterLevel;
    }
    public int getLightLevel()
    {
        return this.lightLevel;
    }
    public int getPhoto_id()
    {
        return this.photo_id;
    }

    public Plant(String name,int waterLevel, int lightLevel,int photo_id)
    {
        this.name = name;
        this.lightLevel = lightLevel;
        this.waterLevel = waterLevel;
        this.photo_id = photo_id;
    }

}

