package com.example.uplantapp;

import android.view.View;

interface CustomItemClickListener {
    void onItemClick(View v, int position);

}
