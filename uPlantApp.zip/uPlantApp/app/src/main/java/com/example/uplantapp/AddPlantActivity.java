package com.example.uplantapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddPlantActivity extends AppCompatActivity {

    //constant
    private static final int RETURN_TAKE_PICTURE=1;

    //Properties
    private Button btnTakePicture;
    private Button btnSavePicture;
    private ImageView imgDisplayPicture;
    private String photoPath= null;
    private Bitmap image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_plant);
        initActivity();
    }

    private void initActivity(){
        //get objects btn and imgView
        btnTakePicture=(Button)findViewById(R.id.btnTakePicture);
        btnSavePicture=(Button)findViewById(R.id.btnSavePicture);
        imgDisplayPicture=(ImageView)findViewById(R.id.imgDisplayPhoto);
        //method for the event
        createOnClickBtnTakePicture();
        createOnClickBtnSavePicture();

    }
    // When click save button
    private void createOnClickBtnSavePicture(){
        btnSavePicture.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                MediaStore.Images.Media.insertImage(getContentResolver(),image,"ImageName","Image saved");
            }
        });

    }

    private void createOnClickBtnTakePicture(){
        btnTakePicture.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                TakePicture();
            }
        });

    }
//Take picture and save it in temporary file
    private void TakePicture(){
        //intent to open a window to take a picture
        Intent intent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //test intent
        if(intent.resolveActivity(getPackageManager())!= null){
            //unique file name (with date)
            String time=new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            File photoDir= getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            try {
                File photoFile=File.createTempFile("photo"+time, ".jpeg",photoDir);
                //enregistrer le chemin complet
                photoPath=photoFile.getAbsolutePath();
                //crée URI, code specifique
                Uri photoUri= FileProvider.getUriForFile(AddPlantActivity.this,
                        AddPlantActivity.this.getApplicationContext().getPackageName()+".provider", photoFile);
                //Transfert Uri vers intent pour enregistrer fichier temporaire
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                //open activity par rapport a l intent
                startActivityForResult(intent,RETURN_TAKE_PICTURE );
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    /**
     * Retoure de l appel de l appareil photo (startActivityForResult)
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        //verifie le bon code de retour (requestCode) et l etat du retour okk(resultCode)
        if(requestCode==RETURN_TAKE_PICTURE && resultCode==RESULT_OK){
            //recuperer image
            image= BitmapFactory.decodeFile(photoPath);
            //afficher l'image
            imgDisplayPicture.setImageBitmap(image);
        }


    }


}
