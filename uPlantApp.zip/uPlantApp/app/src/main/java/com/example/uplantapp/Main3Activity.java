package com.example.uplantapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.GZIPInputStream;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Button startButton = (Button)findViewById(R.id.testButton);

        Intent intent = getIntent();
        final String plantName = intent.getStringExtra("name");
        final String waterLevel = intent.getStringExtra("water");
        final String lightLevel = intent.getStringExtra("light");
        startButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                System.out.println(plantName);
                System.out.println(waterLevel);
                System.out.println(lightLevel);
                PlantsListing.prenoms.add(plantName);

                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            //http://192.168.137.145
                            //URL obj = new URL("https://postman-echo.com/post");
                            URL obj = new URL("http://192.168.43.119");
                            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                            con.setRequestMethod("POST");

                            //con.setRequestProperty("User-Agent", "Mozilla/5.0");
                            //con.setRequestProperty("Accept-Language", "tr,en-US;q=0.9,en;q=0.8");
                            //con.setRequestProperty("Accept-Encoding", "gzip, deflate");
                            //con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");


                            // For POST only - START
                            con.setDoOutput(true);

                            String post_params = "light=" + lightLevel + "&moist=" + waterLevel;
                            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
                            wr.writeBytes(post_params);
                            wr.flush();
                            wr.close();
                            // For POST only - END

                            try {
                                System.out.println(""+con.getContentEncoding());
                                int responseCode = con.getResponseCode();
                                System.out.println("POST Response Code :: " + responseCode);

                                if (responseCode == HttpURLConnection.HTTP_OK) { //success


                                    BufferedReader in = new BufferedReader(new InputStreamReader(
                                            new GZIPInputStream(con.getInputStream())));
                                    String inputLine;
                                    StringBuffer response = new StringBuffer();

                                    while ((inputLine = in.readLine()) != null) {
                                        response.append(inputLine);
                                    }
                                    in.close();

                                    // print result
                                    System.out.println(response.toString());
                                } else {
                                    System.out.println("POST request not worked");
                                }
                            }catch (Exception e){

                            }

                            con.disconnect();
                            /////////////////////////////////////////////
/*
                            URL url = new URL("http://192.168.137.145");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("POST");
                            conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                            conn.setRequestProperty("Accept","application/json");
                            conn.setDoOutput(true);
                            conn.setDoInput(true);

                            JSONObject jsonParam = new JSONObject();
                            //jsonParam.put("plant_name", plantName);
                            jsonParam.put("light", lightLevel);
                            jsonParam.put("moist", waterLevel);
                            Log.i("JSON", jsonParam.toString());

                            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
                            os.writeBytes(jsonParam.toString());

                            os.flush();
                            os.close();
                            */

//                            Log.i("STATUS", String.valueOf(conn.getResponseCode()));
//                            Log.i("MSG" , conn.getResponseMessage());

                            /*
                            if(conn.getResponseCode() == 200) {
                                BufferedReader reader2 = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                                String inputLine;
                                StringBuffer response = new StringBuffer();

                                while ((inputLine = reader2.readLine()) != null) {
                                    response.append(inputLine);
                                }
                                reader2.close();
                                Log.i("Response", response.toString());

                                String str_res = response.toString();
                                JSONObject json_res;
                                try{
                                    json_res = new JSONObject(str_res);
                                    Log.i("JSON", json_res.getString("data"));
                                    Log.i("Files", json_res.getString("files"));
                                } catch (JSONException e) {
                                    Log.e("JSON Parser", "Error parsing data " + e.toString());
                                }

                            }
                            */


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                thread.start();
            }
        });
    }
}